import { Injectable } from '@angular/core';
import { Http, RequestOptions } from '@angular/http';
import { Company } from '../Common/Company'
import { Customer } from '../Common/Customer'
import swal from 'sweetalert2';


@Injectable({
  providedIn: 'root'
})
export class AdminService {
  request : Request
  response : Response
  company : Company = new Company();
  customer : Customer = new Customer()
  protocol: String = "https";
  server: String = "localhost";
  port: String = "8443";
  loginPath = this.protocol + "://" + this.server + ":" + this.port
  adminApiPath = this.protocol + "://" + this.server + ":" + this.port + "/Admin/";
  
  
  constructor(private _http : Http) { 
  }

  logoutService(request, response) {
    return this._http.post(this.adminApiPath + "logout", request, response)
  }

  public getAllCompaniesService(){
    return this._http.get(this.adminApiPath + "getAllCompanies")
  }

  public getCompanyByNameService(company: Company){
    return this._http.get(this.adminApiPath + "getCompanyByName/" + company.name)
  }

  public getCompanyByIDService(company: Company){
    return this._http.get(this.adminApiPath + "getCompanyByID/" + company.id)
  }

  public deleteCompanyService(company: Company){
    return this._http.delete(this.adminApiPath + "removeCompany/" + company.id, new RequestOptions({body: company}))
  }

  public updateCompanyService(company: Company){
    return this._http.put(this.adminApiPath + "updateCompany/" + company.id, company)
  }

  public getAllCustomersService(){
   return this._http.get(this.adminApiPath + "getAllCustomers")
  }

  public getCustomerByNameService(customer: Customer){
    return this._http.get(this.adminApiPath + "getCustomerByName/" + customer.name)
  }

  public getCustomerByIDService(customer: Customer){
    return this._http.get(this.adminApiPath + "getCustomer/" + customer.id)
  }

  public deleteCustomerService(customer: Customer) {
    return this._http.delete(this.adminApiPath + "removeCustomer/" + customer.id, new RequestOptions({body: customer}))
  }
  
  public updateCustomerService(customer: Customer){
    return this._http.put(this.adminApiPath + "updateCustomer/" + customer.id, customer)
  }
}
