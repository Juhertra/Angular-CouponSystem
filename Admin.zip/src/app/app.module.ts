import { BrowserModule } from '@angular/platform-browser';
import { NgModule, Component } from '@angular/core';

import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { HttpClientModule } from '@angular/common/http';
import { RouterModule } from '@angular/router';
import { HashLocationStrategy, LocationStrategy } from '@angular/common'

import { AppComponent } from './app.component';
import { CompanyComponent } from './AdminApp/Components/company/company.component';
import { CustomerComponent } from './AdminApp/Components/customers/customers.component';
import { CreatecustomerComponent } from './AdminApp/Components/createcustomer/createcustomer.component';
import { CreatecompanyComponent } from './AdminApp/Components/createcompany/createcompany.component';
import { SignupComponent } from './signup/signup.component';

import { AdminService } from './services/admin.service';
import { SearchComponent } from './search/search.component'




@NgModule({
  declarations: [
    AppComponent,
    CompanyComponent,
    CustomerComponent,
    CreatecustomerComponent,
    CreatecompanyComponent,
    SignupComponent,
    SearchComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    HttpClientModule,
    RouterModule.forRoot([
      {
        path: 'createcustomer',
        component: CreatecustomerComponent,
      },
      {
        path: 'createcompany',
        component: CreatecompanyComponent,
      },
      {
        path: 'getallcompanies',
        component: CompanyComponent,
      },
      {
        path: 'getallcustomers',
        component: CustomerComponent,
      },
      {
        path: 'search',
        component: SearchComponent,
      }
    ])
  ],
  providers: [AdminService,
    { provide: LocationStrategy, useClass: HashLocationStrategy }],
  exports: [RouterModule],
  bootstrap: [AppComponent],
})
export class AppModule { }
