export class Company{

  constructor(public id?: number, public name?: string, public password?: string, public email?: string)
  {

  }
  
}