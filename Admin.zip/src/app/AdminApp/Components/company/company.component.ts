import { Component, OnInit } from '@angular/core';
import { Company } from '../../../Common/Company';
import { AdminService } from '../../../services/admin.service';
import Swal from 'sweetalert2';


@Component({
  selector: 'app-company',
  templateUrl: './company.component.html',
  styleUrls: ['./company.component.css']
})
export class CompanyComponent implements OnInit {

  public companies: Company[]
  public company: Company

  constructor(private _service: AdminService) {
    this.getAllCompanies()
  }

  ngOnInit() {
  }

  getAllCompanies() {
    this._service.getAllCompaniesService().subscribe(
      (resp) => {
        this.companies = resp.json()
      }
    )
  }
  deleteCompany(company: Company) {
    Swal({
      title: 'Are you sure?',
      text: "Are you sure you want to delete company: " + company.name + "?!",
      type: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes, delete it!'
    }).then((result) => {
      if (result.value) {
        // fire ajax Delete
        this._service.deleteCompanyService(company).subscribe(
          (resp) => {
            console.log(company)
            console.log(resp)
          },
          (err) => {
            console.error('Error while deleting company:' + company.name, err)
            Swal({
              title: 'Error!',
              text: 'Oops... ' + 'Something went wrong!',
              confirmButtonText: 'OK'
            })
          }
        )
      }
    })
  }

  updateCompany(company: Company) {
    Swal({
      title: 'Are you sure?',
      text: "Are you sure you want to update company: " + company.name  + "?!",
      type: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes, update it!'
    }).then((result) => {
      if (result.value) {
        // fire ajax Put
        this._service.updateCompanyService(company).subscribe(
          (resp) => {
            console.log(company)
            console.log(resp)
          },
          (err) => {
            console.error('Error while updating company:' + company.name, err)
            Swal({
              title: 'Error!',
              text: 'Oops... ' + 'Something went wrong!',
              confirmButtonText: 'OK'
            })
          }
        )
      }
    })
  }
}
