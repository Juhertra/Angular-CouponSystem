import { Component, OnInit } from '@angular/core';
import { Customer } from '../../../Common/Customer';
import { AdminService } from '../../../services/admin.service'
import Swal from 'sweetalert2';

@Component({
  selector: 'app-customers',
  templateUrl: './customers.component.html',
  styleUrls: ['./customers.component.css']
})
export class CustomerComponent implements OnInit {

  customers: Customer[]
  customer: Customer

  constructor(private _service: AdminService) {
    this.getAllCustomers()
  }

  ngOnInit() {
  }

  getAllCustomers() {
    this._service.getAllCustomersService().subscribe(
      (resp) => {
        this.customers = resp.json()
      },
      error => {
        error.callback = () => this.customer;
        throw error;
      }
    )
  }

  deleteCustomer(customer: Customer) {
    Swal({
      title: 'Are you sure?',
      text: "You are about to delete customer: " + customer.name + "!",
      type: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes, delete it!'
    }).then((result) => {
      if (result.value) {
        // fire ajax delete
        this._service.deleteCustomerService(customer).subscribe(
          (resp) => {
            console.log(customer)
            console.log(resp)
          },
          (err) => {
            console.error('Error while deleting customer:' + customer.name, err)
            Swal({
              title: 'Error!',
              text: 'Oops... ' + 'Something went wrong!',
              confirmButtonText: 'OK'
            })
          }
        )
      }
    })
  }

  updateCustomer(customer: Customer) {
    Swal({
      title: 'Are you sure?',
      text: "You are about to update customer: " + customer.name + "!",
      type: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes, update it!'
    }).then((result) => {
      if (result.value) {
        // fire ajax Put
        this._service.updateCustomerService(customer).subscribe(
          (resp) => {
            console.log(customer)
            console.log(resp)
          },
          (err) => {
            console.error('Error while updating customer:' + customer.name, err)
            Swal({
              title: 'Error!',
              text: 'Oops... ' + 'Something went wrong!',
              confirmButtonText: 'OK'
            })
          }
        )
      }
    })
  }
}
