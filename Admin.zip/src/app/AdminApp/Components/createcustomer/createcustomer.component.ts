import { Component, OnInit } from '@angular/core';
import { Http } from '@angular/http';
import { Customer } from '../../../Common/Customer';
import { AdminService } from '../../../services/admin.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-createcustomer',
  templateUrl: './createcustomer.component.html',
  styleUrls: ['./createcustomer.component.css']
})
export class CreatecustomerComponent implements OnInit {

  private httpspath: String = "";
  customer: Customer = new Customer

  constructor(private _http: Http, private _service: AdminService) {

    this.httpspath = this._service.adminApiPath;
  }

  ngOnInit() {
  }

  createCustomer() {
    Swal({
      title: 'Are you sure?',
      text: "You are about to create customer " + this.customer.name,
      type: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes, create it!'
    }).then((result) => {
      if (result.value) {
        // fire ajax POST
        this._http.post(this.httpspath + "createCustomer", this.customer).subscribe(
          (resp) => {
            console.log(resp)

          },
          (err) => {
            console.error('Error while creating customer:' + this.customer.name, err)
            Swal({
              title: 'Error!',
              text: 'Oops... ' + 'Something went wrong!',
              confirmButtonText: 'OK'
            })
          }
        )
      }
    })
  }
}
