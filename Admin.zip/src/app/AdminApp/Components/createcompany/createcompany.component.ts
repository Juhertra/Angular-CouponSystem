import { Component, OnInit } from '@angular/core';
import { Http } from '@angular/http';
import { Company } from '../../../Common/Company';
import { AdminService } from '../../../services/admin.service'
import Swal from 'sweetalert2';

@Component({
  selector: 'app-createcompany',
  templateUrl: './createcompany.component.html',
  styleUrls: ['./createcompany.component.css']
})
export class CreatecompanyComponent implements OnInit {

  private httpspath: String = "";
  company: Company = new Company()

  constructor(private _http: Http, private _service: AdminService) {

    this.httpspath = this._service.adminApiPath;

  }

  ngOnInit() {

  }

  createCompany() {

    Swal({
      title: 'Are you sure?',
      text: "You are about to create company: " + this.company.name,
      type: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes, create it!'
    }).then((result) => {
      if (result.value) {
        // fire ajax POST
        this._http.post(this.httpspath + "createCompany", this.company).subscribe(
          (resp) => {
            console.log(resp)
          },
          (err) => {
            console.error('Error while creating company:' + this.company.name, err)
            Swal({
              title: 'Error!',
              text: 'Oops... ' + 'Something went wrong!',
              confirmButtonText: 'OK'
            })
          }
        )
      }
    })
  }

}
