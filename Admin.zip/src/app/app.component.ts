import { Component } from '@angular/core';
import { AdminService } from './services/admin.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'WebCouponSystem';
  request: Request;
  response: Response

  constructor(private _service: AdminService) { }

  logout(response, request) {
    Swal({
      title: 'Are you sure?',
      text: "You are about to logout!",
      type: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes, logout!'
    }).then((result) => {
      if (result.value) {
        this._service.logoutService(this.request, this.response).subscribe(
          (resp) => {
            window.location.href = this._service.loginPath + "/login.html"
          },
          (err) => {
            console.error('Error while loging out Admin', err)
            Swal({
              title: 'Error!',
              text: 'Oops... ' + 'Something went wrong!',
              confirmButtonText: 'OK'
            })
          }
        )
      }
    })

  }

}
