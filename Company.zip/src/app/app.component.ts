import { Component } from '@angular/core';
import { Http } from '@angular/http';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'WebCouponSystemCompany';

  constructor(private _http: Http) {

  }

  logout(response, request) {
    Swal({
      title: 'Are you sure?',
      text: "You are about to logout!",
      type: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes, logout!'
    }).then((result) => {
      if (result.value) {
        this._http.post("https://localhost:8443/Customer/logout", request, response).subscribe(
          (resp) => {
            window.location.href = "https://localhost:8443/login.html"
          },
          (err) => {
            console.error('Error while logging out from Company', err)
            Swal({
              title: 'Error!',
              text: 'Oops... ' + 'Something went wrong!',
              confirmButtonText: 'OK'
            })
          }
        )
      }
    })

  }

}
