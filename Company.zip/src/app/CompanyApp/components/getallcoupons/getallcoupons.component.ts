import { Component, OnInit } from '@angular/core';
import { Http, RequestOptions } from '@angular/http';
import { Coupon } from '../../common/coupon';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-getallcoupons',
  templateUrl: './getallcoupons.component.html',
  styleUrls: ['./getallcoupons.component.css']
})
export class GetallcouponsComponent implements OnInit {
  public coupon: Coupon
  public coupons: Coupon[]
  protocol: String = "https";
  server: String = "localhost";
  port: String = "8443";
  companyApiPath = this.protocol + "://" + this.server + ":" + this.port + "/Company/";

  constructor(private _http: Http) {
    this.getAllCoupons()
  }

  ngOnInit() {
  }

  getAllCoupons() {
    return this._http.get(this.companyApiPath + "getAllCoupons").subscribe(
      (resp) => {
        this.coupons = resp.json()
      }
    )
  }

  public deleteCoupon(coupon: Coupon) {
    Swal({
      title: 'Are you sure?',
      text: "Are you sure you want to delete coupon: " + coupon.title + "?!",
      type: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes, delete it!'
    }).then((result) => {
      if (result.value) {
        // fire ajax Delete
        this._http.delete(this.companyApiPath + "removeCoupon/" + coupon.id, new RequestOptions({ body: coupon })).subscribe(
          (resp) => {
            console.log(coupon)
            console.log(resp)
          },
          (err) => {
            console.error('Error while deleting company:' + coupon.title, err)
            Swal({
              title: 'Error!',
              text: 'Oops... ' + 'Something went wrong!',
              confirmButtonText: 'OK'
            })
          }
        )
      }
    })
  }

  public updateCoupon(coupon: Coupon) {
    Swal({
      title: 'Are you sure?',
      text: "Are you sure you want to update coupon: " + coupon.title + "?!",
      type: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes, update it!'
    }).then((result) => {
      if (result.value) {
        this._http.put(this.companyApiPath + "updateCoupon/" + coupon.id, coupon).subscribe(
          (resp) => {
            console.log(coupon)
            console.log(resp)
          },
          (err) => {
            console.error('Error while updating company:' + coupon.title, err)
            Swal({
              title: 'Error!',
              text: 'Oops... ' + 'Something went wrong!',
              confirmButtonText: 'OK'
            })
          }
        )
      }
    })
  }
}
