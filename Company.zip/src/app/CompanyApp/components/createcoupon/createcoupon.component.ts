import { Component, OnInit } from '@angular/core';
import { Http } from '@angular/http';
import { Coupon } from '../../common/coupon';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-createcoupon',
  templateUrl: './createcoupon.component.html',
  styleUrls: ['./createcoupon.component.css']
})
export class CreatecouponComponent implements OnInit {
  coupon: Coupon = new Coupon();
  coupons: Coupon[];
  protocol: String = "https";
  server: String = "localhost";
  port: String = "8443";
  companyApiPath = this.protocol + "://" + this.server + ":" + this.port + "/Company/";

  constructor(private _http: Http) {
  }

  ngOnInit() {
  }

  createCoupon(coupon: Coupon) {
    Swal({
      title: 'Are you sure?',
      text: "Are you sure you want to create coupon: " + coupon.title + "?!",
      type: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes, create it!'
    }).then((result) => {
      if (result.value) {
        // fire ajax Delete
        this._http.post(this.companyApiPath + "createCoupon", this.coupon).subscribe(
          (resp) => {
            console.log(resp)
          },
          (err) => {
            console.error('Error while creating company:' + coupon.title, err)
            Swal({
              title: 'Error!',
              text: 'Oops... ' + 'Something went wrong!',
              confirmButtonText: 'OK'
            })
          }
        )
      }
    })
  }
}
