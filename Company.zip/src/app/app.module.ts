import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';

import { AppComponent } from './app.component';
import { CreatecouponComponent } from './CompanyApp/components/createcoupon/createcoupon.component';
import { GetallcouponsComponent } from './CompanyApp/components/getallcoupons/getallcoupons.component';

@NgModule({
  declarations: [
    AppComponent,
    CreatecouponComponent,
    GetallcouponsComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    RouterModule.forRoot([
      {
        path: 'createcoupon',
        component: CreatecouponComponent,
      },
      {
        path: 'getallcoupons',
        component: GetallcouponsComponent,
      }
    ]),
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
