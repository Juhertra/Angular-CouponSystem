import { Component, OnInit } from '@angular/core';
import { Coupon } from '../../common/coupon';
import { Http } from '@angular/http'
import Swal from 'sweetalert2';

@Component({
  selector: 'app-purchasecoupon',
  templateUrl: './purchasecoupon.component.html',
  styleUrls: ['./purchasecoupon.component.css']
})
export class PurchaseCouponComponent implements OnInit {
  public coupon: Coupon
  public coupons: Coupon[]
  protocol: String = "https";
  server: String = "localhost";
  port: String = "8443";
  customerApiPath = this.protocol + "://" + this.server + ":" + this.port + "/Customer/";

  constructor(private _http: Http) {
    this.getAllAvailableCoupons();
  }
  ngOnInit() {

  }

  getAllAvailableCoupons() {
    return this._http.get(this.customerApiPath + "getAllAvailableCoupons").subscribe(
      (resp) => {
        this.coupons = resp.json()
      }
    )
  }

  purchaseCoupon(coupon: Coupon) {

    Swal({
      title: 'Are you sure?',
      text: "You are about to purchase coupon: " + coupon.title + "?!",
      type: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes, putchase it!'
    }).then((result) => {
      if (result.value) {
        // fire ajax POST
        this._http.post(this.customerApiPath + "purchaseCoupon", coupon).subscribe(
          (resp) => {
            console.log(resp)
          },
          (err) => {
            console.error('Error while putchasing company:' + coupon.title, err)
            Swal({
              title: 'Error!',
              text: 'Oops... ' + 'Something went wrong!',
              confirmButtonText: 'OK'
            })
          }
        )
      }
    })
  }

}
