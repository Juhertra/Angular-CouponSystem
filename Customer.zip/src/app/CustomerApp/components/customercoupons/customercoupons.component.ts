import { Component, OnInit } from '@angular/core';
import { Http } from '@angular/http';
import { Coupon } from '../../common/coupon';

@Component({
  selector: 'app-customercoupons',
  templateUrl: './customercoupons.component.html',
  styleUrls: ['./customercoupons.component.css']
})
export class CustomerCouponsComponent implements OnInit {
  public coupon: Coupon 
  public coupons: Coupon[]
  protocol: String = "https";
  server: String = "localhost";
  port: String = "8443";
  customerApiPath = this.protocol + "://" + this.server + ":" + this.port + "/Customer/";

  constructor(private _http: Http) {
    this.getAllPurchasedCoupons()
   }

  ngOnInit() {
  }
  getAllPurchasedCoupons() {
    return this._http.get(this.customerApiPath + "getAllPurchasedCoupons").subscribe(
      (resp) => {
        this.coupons = resp.json()
      }
    )
  }

}
