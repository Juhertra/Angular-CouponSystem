import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { HashLocationStrategy, LocationStrategy } from '@angular/common';

import { AppComponent } from './app.component';
import { PurchaseCouponComponent } from './CustomerApp/components/purchasecoupon/purchasecoupon.component';
import { CustomerCouponsComponent } from './CustomerApp/components/customercoupons/customercoupons.component';

@NgModule({
  declarations: [
    AppComponent,
    PurchaseCouponComponent,
    CustomerCouponsComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    RouterModule.forRoot([
      {
        path: 'purchaseCoupon',
        component: PurchaseCouponComponent,
      },
      {
        path: 'ownedCoupon',
        component: CustomerCouponsComponent,
      }
    ]),
  ],
  providers: [{provide: LocationStrategy, useClass: HashLocationStrategy}],
  bootstrap: [AppComponent]
})
export class AppModule { }
